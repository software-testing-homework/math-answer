package com.bookcollection.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bookcollection.dto.LoginRequest;
import com.bookcollection.dto.RegisterRequest;
import com.bookcollection.dto.UserResponse;
import com.bookcollection.entity.SysUser;
import com.bookcollection.mapper.SysUserMapper;
import com.bookcollection.utils.JwtUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.DigestUtils;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private SysUserMapper userMapper;

    @InjectMocks
    private UserService userService;

    private SysUser testUser;
    private RegisterRequest registerRequest;
    private LoginRequest loginRequest;

    @BeforeEach
    void setUp() {
        testUser = new SysUser();
        testUser.setId(1L);
        testUser.setUsername("testuser");
        testUser.setPassword(DigestUtils.md5DigestAsHex("password123".getBytes()));
        testUser.setEmail("test@example.com");
        testUser.setNickname("Test User");
        testUser.setRole(0);
        testUser.setStatus(1);
        testUser.setLoginCount(0);
        testUser.setCreateTime(LocalDateTime.now());
        testUser.setUpdateTime(LocalDateTime.now());

        registerRequest = new RegisterRequest();
        registerRequest.setUsername("newuser");
        registerRequest.setPassword("password123");
        registerRequest.setEmail("new@example.com");

        loginRequest = new LoginRequest();
        loginRequest.setUsername("testuser");
        loginRequest.setPassword("password123");
    }

    @Test
    @DisplayName("测试用户注册 - 成功")
    void testRegister_Success() {
        when(userMapper.selectCount(any(LambdaQueryWrapper.class))).thenReturn(0L);
        when(userMapper.insert(any(SysUser.class))).thenAnswer(invocation -> {
            SysUser user = invocation.getArgument(0);
            user.setId(2L);
            return 1;
        });

        try (MockedStatic<JwtUtils> mockedJwtUtils = mockStatic(JwtUtils.class)) {
            mockedJwtUtils.when(() -> JwtUtils.generateToken(2L, "newuser")).thenReturn("mock-token");

            UserResponse response = userService.register(registerRequest);

            assertNotNull(response);
            assertEquals("newuser", response.getUsername());
            assertEquals("mock-token", response.getToken());
            verify(userMapper).insert(any(SysUser.class));
        }
    }

    @Test
    @DisplayName("测试用户注册 - 用户名已存在")
    void testRegister_UsernameExists() {
        when(userMapper.selectCount(any(LambdaQueryWrapper.class))).thenReturn(1L);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.register(registerRequest);
        });

        assertEquals("用户名、邮箱或手机号已存在", exception.getMessage());
        verify(userMapper, never()).insert(any(SysUser.class));
    }

    @Test
    @DisplayName("测试用户登录 - 成功")
    void testLogin_Success() {
        when(userMapper.selectOne(any(LambdaQueryWrapper.class))).thenReturn(testUser);
        when(userMapper.updateById(any(SysUser.class))).thenReturn(1);

        try (MockedStatic<JwtUtils> mockedJwtUtils = mockStatic(JwtUtils.class)) {
            mockedJwtUtils.when(() -> JwtUtils.generateToken(1L, "testuser")).thenReturn("mock-token");

            UserResponse response = userService.login(loginRequest);

            assertNotNull(response);
            assertEquals("testuser", response.getUsername());
            assertEquals("mock-token", response.getToken());
            verify(userMapper).updateById(any(SysUser.class));
        }
    }

    @Test
    @DisplayName("测试用户登录 - 用户不存在")
    void testLogin_UserNotFound() {
        when(userMapper.selectOne(any(LambdaQueryWrapper.class))).thenReturn(null);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.login(loginRequest);
        });

        assertEquals("用户名或密码错误", exception.getMessage());
    }

    @Test
    @DisplayName("测试用户登录 - 密码错误")
    void testLogin_WrongPassword() {
        LoginRequest wrongPasswordRequest = new LoginRequest();
        wrongPasswordRequest.setUsername("testuser");
        wrongPasswordRequest.setPassword("wrongpassword");

        when(userMapper.selectOne(any(LambdaQueryWrapper.class))).thenReturn(testUser);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.login(wrongPasswordRequest);
        });

        assertEquals("用户名或密码错误", exception.getMessage());
    }

    @Test
    @DisplayName("测试用户登录 - 账户被禁用")
    void testLogin_AccountDisabled() {
        testUser.setStatus(0);
        when(userMapper.selectOne(any(LambdaQueryWrapper.class))).thenReturn(testUser);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.login(loginRequest);
        });

        assertEquals("账户已被禁用", exception.getMessage());
    }

    @Test
    @DisplayName("测试获取用户 - 成功")
    void testGetUserById_Success() {
        when(userMapper.selectById(1L)).thenReturn(testUser);

        SysUser user = userService.getUserById(1L);

        assertNotNull(user);
        assertEquals("testuser", user.getUsername());
    }

    @Test
    @DisplayName("测试获取用户 - 用户不存在")
    void testGetUserById_NotFound() {
        when(userMapper.selectById(999L)).thenReturn(null);

        SysUser user = userService.getUserById(999L);

        assertNull(user);
    }

    @Test
    @DisplayName("测试更新个人资料 - 成功")
    void testUpdateProfile_Success() {
        when(userMapper.selectById(1L)).thenReturn(testUser);
        when(userMapper.updateById(any(SysUser.class))).thenReturn(1);

        SysUser updateData = new SysUser();
        updateData.setNickname("New Nickname");

        SysUser updatedUser = userService.updateProfile(1L, updateData);

        assertNotNull(updatedUser);
        assertEquals("New Nickname", updatedUser.getNickname());
        verify(userMapper).updateById(any(SysUser.class));
    }

    @Test
    @DisplayName("测试更新个人资料 - 用户不存在")
    void testUpdateProfile_UserNotFound() {
        when(userMapper.selectById(999L)).thenReturn(null);

        SysUser updateData = new SysUser();
        updateData.setNickname("New Nickname");

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.updateProfile(999L, updateData);
        });

        assertEquals("用户不存在", exception.getMessage());
    }

    @Test
    @DisplayName("测试修改密码 - 成功")
    void testChangePassword_Success() {
        when(userMapper.selectById(1L)).thenReturn(testUser);
        when(userMapper.updateById(any(SysUser.class))).thenReturn(1);

        assertDoesNotThrow(() -> {
            userService.changePassword(1L, "password123", "newpassword456");
        });

        verify(userMapper).updateById(any(SysUser.class));
    }

    @Test
    @DisplayName("测试修改密码 - 原密码错误")
    void testChangePassword_WrongOldPassword() {
        when(userMapper.selectById(1L)).thenReturn(testUser);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.changePassword(1L, "wrongpassword", "newpassword456");
        });

        assertEquals("原密码不正确", exception.getMessage());
    }

    @Test
    @DisplayName("测试修改密码 - 新密码与原密码相同")
    void testChangePassword_SameAsOld() {
        when(userMapper.selectById(1L)).thenReturn(testUser);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.changePassword(1L, "password123", "password123");
        });

        assertEquals("新密码不能与原密码相同", exception.getMessage());
    }

    @Test
    @DisplayName("测试修改密码 - 新密码长度不符合要求")
    void testChangePassword_InvalidLength() {
        when(userMapper.selectById(1L)).thenReturn(testUser);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.changePassword(1L, "password123", "123");
        });

        assertEquals("新密码长度应为6-20位", exception.getMessage());
    }
}